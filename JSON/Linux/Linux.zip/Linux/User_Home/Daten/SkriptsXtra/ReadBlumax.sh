gpsbabel -D 1 -t -w -i mtk,$1 -f /dev/ttyUSB0 -x "track,move=+1024w,pack,split,title=Blumax %d. %b %Y %H(+2):%M" -o gpx -F "/home/hans/Daten/GPS/Bluxmax-$(date +%d.%b.%Y-%H.%M.%S).gpx"
