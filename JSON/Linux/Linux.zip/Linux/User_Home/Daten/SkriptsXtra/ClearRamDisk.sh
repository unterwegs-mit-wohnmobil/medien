sudo umount /mnt/RamDisk
sudo mount /mnt/RamDisk
df -h
