Windows10Status=$(/Applications/VirtualBox.app/Contents/MacOS/VBoxManage showvminfo "Windows 10" | grep -c "running (since")
if [ $Windows10Status == 1 ]
then
	terminal-notifier -message "Windows 10 wird schlafen gelegt" -title "Sleep_Windows 10"
	/Applications/VirtualBox.app/Contents/MacOS/VBoxManage controlvm "Windows 10" savestate
	terminal-notifier -message "Windows 10 schläft" -title "Sleep_Window 10s"
fi
#
WindowsXPStatus=$(/Applications/VirtualBox.app/Contents/MacOS/VBoxManage showvminfo "Windows XP" | grep -c "running (since")
if [ $WindowsXPStatus  == 1 ]
then
	terminal-notifier -message "Windows XP wird schlafen gelegt" -title "Sleep_Windows XP"
	/Applications/VirtualBox.app/Contents/MacOS/VBoxManage controlvm "Windows XP" savestate
	terminal-notifier -message "Windows XP schläft" -title "Sleep_Windows XP"
fi
#
ElementaryStatus=$(/Applications/VirtualBox.app/Contents/MacOS/VBoxManage showvminfo "Elementary" | grep -c "running (since")
if [ $ElementaryStatus  == 1 ]
then
	terminal-notifier -message "Elementary wird schlafen gelegt" -title "Sleep_Elementary"
	/Applications/VirtualBox.app/Contents/MacOS/VBoxManage controlvm "Elementary" savestate
	terminal-notifier -message "Elementary schläft" -title "Sleep_Elementary"
fi
#
RaspberryStatus=$(/Applications/VirtualBox.app/Contents/MacOS/VBoxManage showvminfo "Raspberry" | grep -c "running (since")
if [ $RaspberryStatus  == 1 ]
then
	terminal-notifier -message "Raspberry wird schlafen gelegt" -title "Sleep_Rasberry"
	/Applications/VirtualBox.app/Contents/MacOS/VBoxManage controlvm "Raspberry" savestate
	terminal-notifier -message "Raspberry schläft" -title "Sleep_Rasberry"
fi
#
ElCapitanStatus=$(/Applications/VirtualBox.app/Contents/MacOS/VBoxManage showvminfo "El Capitan" | grep -c "running (since")
if [ $ElCapitanStatus  == 1 ]
then
	terminal-notifier -message "El Capitan wird schlafen gelegt" -title "Sleep_El Capitan"
	/Applications/VirtualBox.app/Contents/MacOS/VBoxManage controlvm "El Capitan" savestate
	terminal-notifier -message "El Capitan schläft" -title "Sleep_El Capitan"
fi
