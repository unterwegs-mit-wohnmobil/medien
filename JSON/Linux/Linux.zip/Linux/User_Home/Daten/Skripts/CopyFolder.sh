if [ ! -d "$2" ]
then
	echo mkdir -p "$2"
	mkdir -p "$2"
fi
echo rsync -a --info=progress2 --stats --exclude-from ~/.rsync-exclude "$1" "$2"
rsync -a --info=progress2 --stats --exclude-from ~/.rsync-exclude "$1" "$2"