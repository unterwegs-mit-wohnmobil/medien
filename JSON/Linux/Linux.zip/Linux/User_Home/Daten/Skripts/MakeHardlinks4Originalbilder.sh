#
do_create_Hardlinks()
{
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.FDir "-V/Volumes/Webspace/Originalbilder/$1" -B -EV "-C(.*Jahresbericht*|.*Abiturzeitung*)" "-Yif [ ! -e :H/Volumes/Webspace/Bildschirmschoner(Aliase Originalbilder)/$1_:P_:F:H ]; then ln :H:V/:F:H :H/Volumes/Webspace/Bildschirmschoner(Aliase Originalbilder)/$1_:P_:F:H; fi;" -PK "-DA~/Daten/Skripts/MakeHardlinks4Originalbilder_Do.sh"
	. ~/Daten/Skripts/MakeHardlinks4Originalbilder_Do.sh
}
#
do_create_Hardlinks Reiseberichte
do_create_Hardlinks Urlaubsbilder
do_create_Hardlinks Impressionen
do_create_Hardlinks Bergtouren
do_create_Hardlinks Ereignisse
do_create_Hardlinks Familie
do_create_Hardlinks Monika
do_create_Hardlinks Freunde_und_Bekannte
do_create_Hardlinks Hunde
do_create_Hardlinks Sonstige
do_create_Hardlinks Gymnasium_Fuessen
#
java -cp ~/Java/Jar/jfi.jar de.nss.jfi.FDir "-V/Volumes/Webspace/Bildschirmschoner(Aliase Originalbilder)/" -FE -LC-2