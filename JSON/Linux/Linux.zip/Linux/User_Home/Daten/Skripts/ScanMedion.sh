exiftool '-CreateDate<FileModifyDate' -if '!(defined $CreateDate)' -overwrite_original_in_place -P "$1"
exiftool '-ScanMake=Medion' -if '!(defined $ScanMake)' -overwrite_original_in_place -P "$1"
exiftool '-ScanModel=Medion MD 90070' -if '!(defined $ScanModel)' -overwrite_original_in_place -P "$1"
exiftool -AlbumIfImageDescriptionEmpty=x '-originalfilename<basename' '-Copyright=Johann Fischer, Neusaess' '-Artist=Johann Fischer, Neusaess' -overwrite_original_in_place -P "$1"
