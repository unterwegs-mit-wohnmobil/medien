terminal-notifier -message "Check Image Integrity gestartet" -title "Check Image Integrity"
java -cp ~/Java/Jar/jfi.jar de.nss.jfi.FDir "-V$1" -DA~/Daten/Skripts/CheckImages_do.sh -DCUTF-8 "-Yecho check :V/:F; convert :H:V/:F:H /dev/null" -PK -B
. ~/Daten/Skripts/CheckImages_do.sh 2>> ~/Daten/Skripts/CheckImages_error.txt
terminal-notifier -message "Check Image Integrity beendet" -title "Check Image Integrity"