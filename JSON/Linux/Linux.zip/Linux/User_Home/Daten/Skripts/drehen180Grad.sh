mogrify -rotate 180 "$1"
~/Daten/Skripts/MakeThumbnail.sh "$1"