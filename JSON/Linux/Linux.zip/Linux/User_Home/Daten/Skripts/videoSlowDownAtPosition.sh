dirname=$(dirname "$1")
filename=$(basename "$1")
basename="${filename%.*}"
extent="${filename##*.}"
#ffmpeg -i "$1" -t $2 "$dirname/$basename.left.$extent" -ss $2 "$dirname/$basename.right.$extent"
ffmpeg -ss $2 -i "$1" -vframes 1 -q:v 2 -y "$dirname/$basename.middle.jpg" 
#ffmpeg -loop 1 -i "$dirname/$basename.middle.jpg"  -t $3 -y "$dirname/$basename.middle.$extent"
#ffmpeg -i "$dirname/$basename.left.$extent" -i "$dirname/$basename.middle.$extent" -i "$dirname/$basename.right.$extent" -filter_complex "[0:v] [1:v] [2:v] concat=n=3:v=1 [v]" -map "[v]" -y "$dirname/$basename.enlarged_$2.$3.sec.$extent"
#rm "$dirname/$basename.left.$extent" 
#rm "$dirname/$basename.right.$extent" 
#rm "$dirname/$basename.middle.jpg" 
#rm "$dirname/$basename.middle.$extent" 
# ffmpeg -i "$1" -filter_complex "[0:v]trim=0:0.1,setpts=10*(PTS-STARTPTS)[v1]; [0:v]trim=0.1:0.5,setpts=5*(PTS-STARTPTS)[v2]; [0:v]trim=0.5:1,setpts=3*(PTS-STARTPTS)[v3]; [0:v]trim=1:2,setpts=3*(PTS-STARTPTS)[v4]; [0:v]trim=2:3,setpts=1.7*(PTS-STARTPTS)[v5]; [0:v]trim=3:5,setpts=1.3*(PTS-STARTPTS)[v6]; [0:v]trim=5:31,setpts=PTS-STARTPTS[v7]; [0:v]trim=31:33,setpts=1.3*(PTS-STARTPTS)[v8]; [0:v]trim=33:34,setpts=1.7*(PTS-STARTPTS)[v9]; [0:v]trim=34:35,setpts=3*(PTS-STARTPTS)[v10]; [0:v]trim=35:35.5,setpts=3*(PTS-STARTPTS)[v11]; [0:v]trim=35.5:35.9,setpts=5*(PTS-STARTPTS)[v12]; [0:v]trim=35.9:36,setpts=10*(PTS-STARTPTS)[v13]; [v1][v2][v3][v4][v5][v6][v7][v8][v9][v10][v11][v12][v13] concat=n=13:v=1" -preset superfast -profile:v baseline -y "$dirname/$basename.slowstartAndEnd.$extent"

