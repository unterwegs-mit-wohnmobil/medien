dirname=$(dirname "$1")
filename=$(basename "$1")
basename="${filename%.*}"
extent="${filename##*.}"
ffmpeg -ss 00:00:00 -i "$1" -vframes 1 -q:v 2 -y "$dirname/$basename.opening.jpg" 
ffmpeg -loop 1 -i "$dirname/$basename.opening.jpg"  -t $2 -y "$dirname/$basename.opening.$extent"
ffmpeg -sseof -1 -i "$1" -update 1 -q:v 2 -y "$dirname/$basename.closing.jpg"
ffmpeg -loop 1 -i "$dirname/$basename.closing.jpg"  -t $2 -y "$dirname/$basename.closing.$extent"
#ffmpeg -i "$dirname/$basename.slowstart.$extent" -to -sseof 5 "$dirname/$basename.slowstart.main.$extent" -sseof -5 "$dirname/$basename.last5.$extent"
ffmpeg -i "$dirname/$basename.opening.$extent" -i "$dirname/$basename.slowstart.$extent" -i "$dirname/$basename.closing.$extent" -filter_complex "[0:v] [1:v] [2:v] concat=n=3:v=1 [v]" -map "[v]" -y "$dirname/$basename.enlarged_$2.sec.$extent"
#rm "$dirname/$basename.opening.jpg" 
#rm "$dirname/$basename.opening.$extent" 
#rm "$dirname/$basename.closing.jpg" 
#rm "$dirname/$basename.closing.$extent" 
