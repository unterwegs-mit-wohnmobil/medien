if [ -d /Volumes/Work/Bilder/f_FotosCloud ]
then
# 	terminal-notifier -message "iCloud-Fotos werden extrahiert" -title "iCloud-Fotos"
	# copy aus Export nur zu/bei Testzwecken
	# rm /Volumes/Work/Bilder/f_FotosCloud/bearbeitet/*.*
	# rm /Volumes/Work/Bilder/f_FotosCloud/Originale/*.*
	# ditto /Volumes/Work/Bilder/f_FotosCloud_Export/bearbeitet/*.* /Volumes/Work/Bilder/f_FotosCloud/bearbeitet/
	# ditto /Volumes/Work/Bilder/f_FotosCloud_Export/Originale/*.* /Volumes/Work/Bilder/f_FotosCloud/Originale/
	exiftool -Filename -Basename -FileExtension -FileTypeExtension -Imagesize '-Filesize#' -DateTimeOriginal -CreateDate -T -ext JPEG -ext JPG -ext CR2 -ext PNG -ext MP4 -ext MOV /Volumes/Work/Bilder/f_FotosCloud/Originale > /Volumes/Work/Bilder/f_FotosCloud/Originale.txt
	java -cp /Volumes/User-Dokumente/Jar/jfiTest.jar de.nss.jfi.Datei2Tabelle -E/Volumes/Work/Bilder/f_FotosCloud/Originale.txt -CUTF-8 -D/Volumes/Work/Bilder/f_FotosCloud/FotosWork.sqlite -TOriginale -N -F -O
	exiftool -Filename -Basename -FileExtension -FileTypeExtension -Imagesize '-Filesize#' -DateTimeOriginal -CreateDate -T -ext JPEG -ext JPG -ext CR2 -ext PNG -ext MP4 -ext MOV /Volumes/Work/Bilder/f_FotosCloud/bearbeitet > /Volumes/Work/Bilder/f_FotosCloud/Bearbeitet.txt
	java -cp /Volumes/User-Dokumente/Jar/jfiTest.jar de.nss.jfi.Datei2Tabelle -E/Volumes/Work/Bilder/f_FotosCloud/Bearbeitet.txt -CUTF-8 -D/Volumes/Work/Bilder/f_FotosCloud/FotosWork.sqlite -TBearbeitet -N -F -O
	java -cp /Volumes/User-Dokumente/Jar/jfiTest.jar de.nss.jfi.Tabelle2Datei -A/Volumes/Work/Bilder/f_FotosCloud/UpdateDateTimeOriginal.sh -D/Volumes/Work/Bilder/f_FotosCloud/FotosWork.sqlite -TUpdateDateTimeOriginal
	/Volumes/Work/Bilder/f_FotosCloud/UpdateDateTimeOriginal.sh
	java -cp /Volumes/User-Dokumente/Jar/jfiTest.jar de.nss.jfi.Tabelle2Datei -A/Volumes/Work/Bilder/f_FotosCloud/UseJPGStattPNG.sh -D/Volumes/Work/Bilder/f_FotosCloud/FotosWork.sqlite -TUseJPGStattPNG -FBefehl
	/Volumes/Work/Bilder/f_FotosCloud/UseJPGStattPNG.sh
	java -cp /Volumes/User-Dokumente/Jar/jfiTest.jar de.nss.jfi.Tabelle2Datei -A/Volumes/Work/Bilder/f_FotosCloud/DeleteDuplicateInBearbeitet.sh -D/Volumes/Work/Bilder/f_FotosCloud/FotosWork.sqlite -TDeleteDuplicateInBearbeitet -FBefehl
	/Volumes/Work/Bilder/f_FotosCloud/DeleteDuplicateInBearbeitet.sh
	java -cp /Volumes/User-Dokumente/Jar/jfiTest.jar de.nss.jfi.Tabelle2Datei -A/Volumes/Work/Bilder/f_FotosCloud/png2jpg.sh -D/Volumes/Work/Bilder/f_FotosCloud/FotosWork.sqlite -Tpng2jpg
	/Volumes/Work/Bilder/f_FotosCloud/png2jpg.sh
	java -cp /Volumes/User-Dokumente/Jar/jfiTest.jar de.nss.jfi.Tabelle2Datei -A/Volumes/Work/Bilder/f_FotosCloud/RenameExtent.sh -D/Volumes/Work/Bilder/f_FotosCloud/FotosWork.sqlite -TRenameExtent
	/Volumes/Work/Bilder/f_FotosCloud/RenameExtent.sh
else
	echo "Platte Work nicht gemountet"
fi
