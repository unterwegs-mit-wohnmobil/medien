find "$1" -type f -mindepth 2 -execdir mv -n "{}" .. \;
java -cp ~/Java/Jar/jfi.jar de.nss.jfi.FDir "-V$1" -FE -I