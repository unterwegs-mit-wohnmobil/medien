ditto /Users/hans/Java/Jar/jfi.jar /Volumes/Daten/Dropbox/Tipps/Linux/User_Home/Java/Jar/jfi.jar
ditto /Users/hans/.ExifTool_config /Volumes/Daten/Dropbox/Tipps/Linux/User_Home/Daten/File4Home/.ExifTool_config
ditto /Volumes/User-Dokumente/ExifTags /Volumes/Daten/Dropbox/Tipps/Linux/User_Home/Daten/ExifTags
rm -f /Volumes/Daten/Dropbox/Tipps/Linux/User_Home/Daten/Skripts/*.*
cp ~/Daten/Skripts/*.sh /Volumes/Daten/Dropbox/Tipps/Linux/User_Home/Daten/Skripts
find /Volumes/Daten/Dropbox/Tipps/Linux/User_Home/Daten/Skripts -type f -name "*.sh" | xargs sed -i '' 's/\/Volumes\/User-Dokumente\/Skripts/~\/Daten\/Skripts/g' 
find /Volumes/Daten/Dropbox/Tipps/Linux/User_Home/Daten/Skripts -type f -name "*.sh" | xargs sed -i '' 's/exiftool/exiftool/g' 
find /Volumes/Daten/Dropbox/Tipps/Linux/User_Home/Daten/Skripts -type f -name "*.sh" | xargs sed -i '' 's/ sed / sed /g' 
find /Volumes/Daten/Dropbox/Tipps/Linux/User_Home/Daten/Skripts -type f -name "*.sh" | xargs sed -i '' '/export PATH=$PATH:\/usr\/local\/bin:\/usr\/local\/sbin/d' 
