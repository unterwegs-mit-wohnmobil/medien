hdidOutput=$(hdid -nomount ram://$((2048*12288)) | cut -d ' ' -f 1) && diskutil erasedisk APFS RamDisk $hdidOutput
mkdir /Volumes/RamDisk/Fotos
mkdir /Volumes/RamDisk/Videos
mkdir /Volumes/RamDisk/Work
mkdir /Volumes/RamDisk/Test
mkdir /Volumes/RamDisk/Originale
mkdir /Volumes/RamDisk/Auswahl
mkdir /Volumes/RamDisk/RamCheck

