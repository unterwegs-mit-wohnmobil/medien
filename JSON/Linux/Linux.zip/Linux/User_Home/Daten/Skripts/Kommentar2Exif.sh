java -cp ~/Java/Jar/jfi.jar de.nss.jfi.FUti -FC -TE "-E$1"
# alt, nur Kommentar
#mdls -name kMDItemFinderComment "$1" > /Volumes/Daten/Work/Temp/KommentarZeile.txt
#if [ -s /Volumes/Daten/Work/Temp/KommentarZeile.txt ]
#then 
#	gsed -i 's/\x61\xCC\x88/\xC3\xA4/g;s/\x41\xCC\x88/\xC3\x84/g;s/\x6F\xCC\x88/\xC3\xB6/g;s/\x4F\xCC\x88/\xC3\x96/g;s/\x75\xCC\x88/\xC3\xBC/g;s/\x55\xCC\x88/\xC3\x9C/g;s/"//g' /Volumes/Daten/Work/Temp/KommentarZeile.txt
#	awk -F' = ' '{print "-xmp:Description="$2}' /Volumes/Daten/Work/Temp/KommentarZeile.txt > /Volumes/Daten/Work/Temp/Kommentar.txt
#	awk -F' = ' '{print ""$2}' /Volumes/Daten/Work/Temp/KommentarZeile.txt > /Volumes/Daten/Work/Temp/KommentarExifCheck.txt
#	exiftool -xmp:Description -T "$1"  > /Volumes/Daten/Work/Temp/KommentarExif.txt	
#	diff /Volumes/Daten/Work/Temp/KommentarExif.txt /Volumes/Daten/Work/Temp/KommentarExifCheck.txt  > /Volumes/Daten/Work/Temp/KommentarExifCheckResult.txt
#	if [ -s /Volumes/Daten/Work/Temp/KommentarExifCheckResult.txt ]
#	then 
# 		exiftool "-BaseName>xmp:Title" -@ /Volumes/Daten/Work/Temp/Kommentar.txt "$1" -overwrite_original_in_place -P	
#	fi
#fi