~/Daten/Skripts/Kommentar2Exif.sh "/Volumes/Work/Mediathek_Downloads/_Elements/WaPo Bodensee/WaPo Bodensee (37) - Vom Fischer und seiner Frau.mp4"
~/Daten/Skripts/Kommentar2Exif.sh "/Volumes/Work/Mediathek_Downloads/_Passport/Alles was recht ist - Die italienische Variante.mp4"
~/Daten/Skripts/Kommentar2Exif.sh "/Volumes/Work/Mediathek_Downloads/_Passport/Alles was recht ist.mp4"
~/Daten/Skripts/Kommentar2Exif.sh "/Volumes/Work/Mediathek_Downloads/_Passport/Der Hafenpastor.mp4"
