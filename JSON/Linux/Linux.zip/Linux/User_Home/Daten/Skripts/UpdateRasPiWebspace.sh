#
# Diashows mit Videos nur bei Bedarf synchroniseren, da jedes Mal die Links umgeändert werden müssen
Reiseberichte=1
Impressionen=1
Bergtouren=1
Taekwondo=1
Gymnasium_Fuessen=1
#
clear
#
Uncomment()
{
	echo "uncomment $1"
	gsed 's/<!--//' "$1" >"/Volumes/Work/Work/Uncomment.htm"
	gsed 's/-->//' "/Volumes/Work/Work/Uncomment.htm" >"$1"
}
#
if [ $Reiseberichte == 1 ]
then
	~/Daten/Skripts/Sync_Folder.sh /Volumes/Webspace/bplaced4/www/Reiseberichte/ /Volumes/RasPi-Daten/Webspace/bplaced4/www/Reiseberichte/
	~/Daten/Skripts/Sync_Folder.sh /Volumes/Webspace/lima-city4/Reiseberichte/ /Volumes/RasPi-Daten/Webspace/lima-city4/Reiseberichte/
	Uncomment /Volumes/RasPi-Daten/Webspace/lima-city4/Reiseberichte/index.htm
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city4/Reiseberichte/htaccess/2018_05_Bretagne/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city4/Reiseberichte/htaccess/2019_04_Allgaeu/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city4/Reiseberichte/htaccess/2019_04_Franken/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city4/Reiseberichte/htaccess/2019_05_Burgund_und_Jura/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city4/Reiseberichte/htaccess/2019_10_Burgund_und_Jura/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city4/Reiseberichte/htaccess/2019_11_Schleissheim_und_Landshut/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city4/Reiseberichte/htaccess/2020_06_Mittelfranken/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city4/Reiseberichte/htaccess/2020_09_10_Nordbayern/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city4/Reiseberichte/htaccess/2020_09_Gelber_Berg/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city4/Reiseberichte/htaccess/2021_05_Gelber_Berg/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city4/Reiseberichte/htaccess/2021_07_Krumbach_Glaserhof/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city4/Reiseberichte/htaccess/2021_09_Oberpfalz/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city4/Reiseberichte/htaccess/2021_10_Inn_Salzach_Rott/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city4/Reiseberichte/htaccess/2022_04_05_Vogesen_Jura/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city4/Reiseberichte/htaccess/2022_04_Alb/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city4/Reiseberichte/htaccess/2022_05_Freising_Moosburg/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city4/Reiseberichte/htaccess/2022_09_Ostalb/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city4/Reiseberichte/htaccess/2022_10_Lothringen/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
#
#	~/Daten/Skripts/Sync_Folder.sh /Volumes/Webspace/bplaced4/www/Reiseberichte_Auswahl/ /Volumes/RasPi-Daten/Webspace/bplaced4/www/Reiseberichte_Auswahl/
	~/Daten/Skripts/Sync_Folder.sh /Volumes/Webspace/lima-city4/Reiseberichte_Auswahl/ /Volumes/RasPi-Daten/Webspace/lima-city4/Reiseberichte_Auswahl/
	Uncomment /Volumes/RasPi-Daten/Webspace/lima-city4/Reiseberichte_Auswahl/index.htm
fi
#
if [ $Impressionen == 1 ]
then
	~/Daten/Skripts/Sync_Folder.sh /Volumes/Webspace/bplaced1/www/Impressionen/ /Volumes/RasPi-Daten/Webspace/bplaced1/www/Impressionen/
	~/Daten/Skripts/Sync_Folder.sh /Volumes/Webspace/lima-city1/Impressionen/ /Volumes/RasPi-Daten/Webspace/lima-city1/Impressionen/
	Uncomment /Volumes/RasPi-Daten/Webspace/lima-city1/Impressionen/index.htm
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city1/Impressionen/htaccess/2020_06ff_Sonntagmorgenrunden/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
fi
#
if [ $Gymnasium_Fuessen == 1 ]
then
	~/Daten/Skripts/Sync_Folder.sh /Volumes/Webspace/bplaced1/www/Gymnasium_Fuessen/ /Volumes/RasPi-Daten/Webspace/bplaced1/www/Gymnasium_Fuessen/
	~/Daten/Skripts/Sync_Folder.sh /Volumes/Webspace/lima-city2/Gymnasium_Fuessen/ /Volumes/RasPi-Daten/Webspace/lima-city2/Gymnasium_Fuessen/
	Uncomment /Volumes/RasPi-Daten/Webspace/lima-city2/Gymnasium_Fuessen/index.htm
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city2/Gymnasium_Fuessen/htaccess/Videos/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
fi
#
if [ $Bergtouren == 1 ]
then
	~/Daten/Skripts/Sync_Folder.sh /Volumes/Webspace/bplaced2/www/Bergtouren/ /Volumes/RasPi-Daten/Webspace/bplaced2/www/Bergtouren/
	~/Daten/Skripts/Sync_Folder.sh /Volumes/Webspace/lima-city2/Bergtouren/ /Volumes/RasPi-Daten/Webspace/lima-city2/Bergtouren/
	Uncomment /Volumes/RasPi-Daten/Webspace/lima-city2/Bergtouren/index.htm
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city2/Bergtouren/htaccess/1975_08_09_Dauphine/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city2/Bergtouren/htaccess/1975_08f_Dauphine/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
fi
#
if [ $Taekwondo == 1 ]
then
	~/Daten/Skripts/Sync_Folder.sh /Volumes/Webspace/bplaced3/www/Taekwondo/ /Volumes/RasPi-Daten/Webspace/bplaced3/www/Taekwondo/
	~/Daten/Skripts/Sync_Folder.sh /Volumes/Webspace/lima-city2/Taekwondo/ /Volumes/RasPi-Daten/Webspace/lima-city2/Taekwondo/
	Uncomment /Volumes/RasPi-Daten/Webspace/lima-city2/Taekwondo/index.htm
	~/Daten/Skripts/Sync_Folder.sh /Volumes/Webspace/bplaced2/www/TKD_Spezial/ /Volumes/RasPi-Daten/Webspace/bplaced2/www/TKD_Spezial/
	~/Daten/Skripts/Sync_Folder.sh /Volumes/Webspace/lima-city2/TKD_Spezial/ /Volumes/RasPi-Daten/Webspace/lima-city2/TKD_Spezial/
	Uncomment /Volumes/RasPi-Daten/Webspace/lima-city2/TKD_Spezial/index.htm
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city2/Taekwondo/htaccess/2015_07_19_Vorfuehrung_Seniorenzentrum_Neusaess/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city2/Taekwondo/htaccess/2016_06_26_Vorfuehrung_Seniorenzentrum_Neusaess/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city2/Taekwondo/htaccess/2016_08_14_Vorfuehrung_Marktfest_Welden/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city2/Taekwondo/htaccess/2016_09_24_Vorfuehrung_Turamichelefest/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city2/Taekwondo/htaccess/2017_07_09_Vorfuehrung_Stadtfest_Neusaess/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city2/TKD_Spezial/htaccess/2017_03_04_Freies_Training/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city2/TKD_Spezial/htaccess/2019_03_02_Max_Salto/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Diashow -V/Volumes/RasPi-Daten/Webspace/lima-city2/TKD_Spezial/htaccess/2019_03_09_Frey_Training/ -RVV/Volumes/RasPi-Daten/Webspace/ -GT -UWV
fi
#
~/Daten/Skripts/Sync_Folder.sh /Volumes/Webspace/lima-city4/Reisefotos/ /Volumes/RasPi-Daten/Webspace/lima-city4/Reisefotos/
#
~/Daten/Skripts/Sync_Folder.sh /Volumes/Webspace/lima-city2/Ereignisse/ /Volumes/RasPi-Daten/Webspace/lima-city2/Ereignisse/
Uncomment /Volumes/RasPi-Daten/Webspace/lima-city2/Ereignisse/index.htm
#
~/Daten/Skripts/Sync_Folder.sh /Volumes/Webspace/lima-city2/Familie/ /Volumes/RasPi-Daten/Webspace/lima-city2/Familie/
Uncomment /Volumes/RasPi-Daten/Webspace/lima-city2/Familie/index.htm
#
~/Daten/Skripts/Sync_Folder.sh /Volumes/Webspace/lima-city2/Monika/ /Volumes/RasPi-Daten/Webspace/lima-city2/Monika/
Uncomment /Volumes/RasPi-Daten/Webspace/lima-city2/Monika/index.htm
#
~/Daten/Skripts/Sync_Folder.sh /Volumes/Webspace/lima-city2/Freunde_und_Bekannte/ /Volumes/RasPi-Daten/Webspace/lima-city2/Freunde_und_Bekannte/
Uncomment /Volumes/RasPi-Daten/Webspace/lima-city2/Freunde_und_Bekannte/index.htm
#
~/Daten/Skripts/Sync_Folder.sh /Volumes/Webspace/lima-city1/Hunde/ /Volumes/RasPi-Daten/Webspace/lima-city1/Hunde/
Uncomment /Volumes/RasPi-Daten/Webspace/lima-city1/Hunde/index.htm
#
~/Daten/Skripts/Sync_Folder.sh /Volumes/Webspace/lima-city1/Tommy/ /Volumes/RasPi-Daten/Webspace/lima-city1/Tommy/
Uncomment /Volumes/RasPi-Daten/Webspace/lima-city1/Tommy/index.htm
#
~/Daten/Skripts/Sync_Folder.sh /Volumes/Webspace/lima-city1/Rezepte/ /Volumes/RasPi-Daten/Webspace/lima-city1/Rezepte/
Uncomment /Volumes/RasPi-Daten/Webspace/lima-city1/Rezepte/index.htm
#
~/Daten/Skripts/Sync_Folder.sh /Volumes/Webspace/lima-city1/Sonstige/ /Volumes/RasPi-Daten/Webspace/lima-city1/Sonstige/
Uncomment /Volumes/RasPi-Daten/Webspace/lima-city1/Sonstige/index.htm
#
~/Daten/Skripts/Sync_Folder.sh /Volumes/Webspace/lima-city1/Videos_auf_Festplatten/ /Volumes/RasPi-Daten/Webspace/lima-city1/Videos_auf_Festplatten/
Uncomment /Volumes/RasPi-Daten/Webspace/lima-city1/Videos_auf_Festplatten/index.htm
#
~/Daten/Skripts/Sync_Folder.sh /Volumes/Webspace/lima-city3/Urlaubsbilder/ /Volumes/RasPi-Daten/Webspace/lima-city3/Urlaubsbilder/
Uncomment /Volumes/RasPi-Daten/Webspace/lima-city3/Urlaubsbilder/index.htm
#
~/Daten/Skripts/Sync_Folder.sh /Volumes/Webspace/lima-city3/Scherry/ /Volumes/RasPi-Daten/Webspace/lima-city3/Scherry/
Uncomment /Volumes/RasPi-Daten/Webspace/lima-city3/Scherry/index.htm
#
ditto /Volumes/Webspace/index.htm /Volumes/RasPi-Daten/Webspace/index.htm
ditto /Volumes/Webspace/indexAlles.htm /Volumes/RasPi-Daten/Webspace/indexAlles.htm
#