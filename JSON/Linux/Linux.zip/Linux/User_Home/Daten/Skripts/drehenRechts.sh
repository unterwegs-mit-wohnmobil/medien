mogrify -rotate 90 "$1"
~/Daten/Skripts/MakeThumbnail.sh "$1"