DIR="/Volumes/RamDisk"
# look for empty dir 
if [ "$(ls -A $DIR/Fotos)" ] || [ "$(ls -A $DIR/Videos)" ] || [ "$(ls -A $DIR/Work)" ] 
then 
	terminal-notifier -message "sichern $DIR" -title "Save_Ramdisk"
	tstamp=$(date +"%Y-%m-%d_%H-%M-%S")
	if [ "$(ls -A $DIR/Fotos)" ] 
	then 
		ditto "$DIR/Fotos" /Volumes/Work/Work/RamDiskSave/$tstamp/Fotos
	fi
	if [ "$(ls -A $DIR/Videos)" ] 
	then 
		ditto "$DIR/Videos" /Volumes/Work/Work/RamDiskSave/$tstamp/Videos
	fi
	if [ "$(ls -A $DIR/Work)" ] 
	then 
		ditto "$DIR/Work" /Volumes/Work/Work/RamDiskSave/$tstamp/Work
	fi
	# leere Verzeichnisse löschen
	java -cp /Users/hans/Java/Jar/jfi.jar de.nss.jfi.FDir -V/Volumes/Work/Work/RamDiskSave/ -FE -I -N-1
	terminal-notifier -message "gesichert $DIR" -title "Save_Ramdisk"
else
	terminal-notifier -message "$DIR nicht vorhanden oder keine Dateien in $DIR" -title "Save_Ramdisk"
fi
