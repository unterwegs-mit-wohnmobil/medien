mogrify -rotate 270 "$1"
~/Daten/Skripts/MakeThumbnail.sh "$1"