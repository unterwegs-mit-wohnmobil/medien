dirname=$(dirname "$1")
filename=$(basename "$1")
basename="${filename%.*}"
extent="${filename##*.}"
ffmpeg -i "$1" -acodec copy -vcodec libx264 -loglevel fatal -stats -b:v 1100k -r 25 -vf scale=720:576 "$dirname/$basename.mp4"