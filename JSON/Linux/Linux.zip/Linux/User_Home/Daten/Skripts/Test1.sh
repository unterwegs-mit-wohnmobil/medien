#
if [ -d /Volumes/Passport/Originalbilder ] && [ -d /Volumes/Webspace/Originalbilder ] 
then
	terminal-notifier -message "Originalbilder werden mit Passport/Originalbilder synchronisiert" -title "Sync_Mac"
#		do_rsync /Volumes/Webspace/Originalbilder/ /Volumes/Passport/Originalbilder/
	terminal-notifier -message "Originalbilder sind mit Passport/Originalbilder synchronisiert" -title "Sync_Mac"
fi
