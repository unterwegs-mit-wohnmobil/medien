ramdiskSizeMB=$(osascript -e 'return text returned of (display dialog "RAM disk size in MB" default answer "8192")')
if [ "$ramdiskSizeMB" != "" ]
then
  fsType="APFS"
  if [ "$ramdiskName" == "" ] 
  then
    ramdiskName="RamDisk"
  fi
  echo Creating RAM disk $ramdiskName of size $ramdiskSizeMB MB with FS type $fsType
  hdidOutput=$(hdid -nomount ram://$((2048*ramdiskSizeMB)) | cut -d ' ' -f 1) && diskutil erasedisk "$fsType" "$ramdiskName" $hdidOutput
  mkdir "/Volumes/$ramdiskName/Fotos"
  mkdir "/Volumes/$ramdiskName/Videos"
  mkdir "/Volumes/$ramdiskName/Work"
  mkdir "/Volumes/$ramdiskName/Test"
  mkdir "/Volumes/$ramdiskName/Originale"
  mkdir "/Volumes/$ramdiskName/Auswahl"
  mkdir "/Volumes/$ramdiskName/RamCheck"
fi