osascript -e 'quit app "DB Browser for SQLite"'
java -cp ~/Java/Jar/jfi.jar de.nss.jfi.FUti -HW/Volumes/Daten/Dropbox/GPS/ -FMTS
java -cp ~/Java/Jar/jfi.jar de.nss.jfi.FUti "-HW/Users/hans/Library/Mobile Documents/com~apple~CloudDocs/GPS/" -FMTK