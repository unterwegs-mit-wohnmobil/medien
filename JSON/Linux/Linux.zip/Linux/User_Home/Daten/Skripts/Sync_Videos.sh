clear
do_rsync()
{
	echo "rsync $1 ==> $2, Modus=$Modus"
	if [ ! -d "$2" ]
	then
		echo mkdir -p "$2"
		mkdir -p "$2"
	fi
	echo "rsync $dryRun -a --stats --delete --exclude-from ~/.rsync-exclude '$1' '$2'"
	rsync $dryRun -a --stats --delete --exclude-from ~/.rsync-exclude "$1" "$2"
}
do_Sync_Videos()
for kat in /Volumes/NAS_HD/Videos/* ;
do
    if [ -d "$kat" ]
    then
		for volume in "BackupPassport" "BackupSeagate" "Passport" "Seagate"  ;
  		do
			ziel="/Volumes/$volume/Videos/$(basename "$kat")"
			if [ -d $ziel ]
			then
				terminal-notifier -message "$kat wird auf $ziel gesichert" -title "Sync_Videos"
				do_rsync "$kat/" "$ziel/"
				terminal-notifier -message "$kat ist auf $ziel gesichert" -title "Sync_Videos"
			fi
  		done
    fi
done
#
do_Sync_Videos