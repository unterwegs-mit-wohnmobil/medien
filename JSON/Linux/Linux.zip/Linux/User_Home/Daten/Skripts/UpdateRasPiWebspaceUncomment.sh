gsed 's/<!--//' "$1" >"/Volumes/Work/Work/Uncomment.htm"
gsed 's/-->//' "/Volumes/Work/Work/Uncomment.htm" >"$1"