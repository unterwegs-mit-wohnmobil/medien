exiftool -ext mp4 -basename -xmp:description -xmp:title "-duration#" -T $1 >$1/_videos.txt
# exiftool -ext mp4 -basename -imagedescription -imagedescription "-duration#" -T $1 >$1/_videos.txt
# exiftool -ext mp4 -basename -basename -basename "-duration#" -T $1 >$1/_videos.txt
