dirname=$(dirname "$1")
filename=$(basename "$1")
basename="${filename%.*}"
#
if [ ! -d "$dirname/_Poster" ]
then
	mkdir "$dirname/_Poster"
fi
exiftool -b -CoverArt "$1" > "$dirname/_Poster/$basename.jpg"