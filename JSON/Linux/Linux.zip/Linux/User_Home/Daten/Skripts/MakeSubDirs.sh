for d in "$1"/* 
do
  if [ -d "$d" ] 
  then
    if [ ! -d "$d"/"$2" ]
		then
		echo mkdir -p "$d"/"$2"
		mkdir -p "$d"/"$2"
	fi
  fi
done
