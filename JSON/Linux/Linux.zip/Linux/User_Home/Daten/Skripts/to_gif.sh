dirname=$(dirname "$1")
filename=$(basename "$1")
basename="${filename%.*}"
extent="${filename##*.}"
output="$dirname/$basename.gif"
#
echo "Input : $1"
echo "Output: $output"
ffmpeg -i "$1" "$output"
#exiftool -tagsFromFile "$1" -all:all "-DateTimeOriginal<CreateDate" -overwrite_original_in_place "$output"
#exiftool -rotation=0 -overwrite_original_in_place "$output"
#~/Daten/Skripts/MakeThumbnail.sh "$output"