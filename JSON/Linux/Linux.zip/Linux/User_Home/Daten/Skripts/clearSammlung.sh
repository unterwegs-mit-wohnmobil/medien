dirname=$(dirname "$1")
basename=$(basename "$1")
#
if [ ! -d "$dirname/ClearDust" ]
then
	mkdir "$dirname/ClearDust"
fi
convert "$1" -set colorspace RGB -colorspace sRGB \( +clone -channel RGB -alpha off -write image.png -statistic maximum 8x8 -write max.png \) "+swap" \( -clone 1 -write x.png -alpha on -channel A -level 70%,75% -separate -negate -distort SRT 0,0,1,0,0.5,1.5 -write dust.png \) -alpha off -compose Over -composite "$dirname/ClearDust/$basename"