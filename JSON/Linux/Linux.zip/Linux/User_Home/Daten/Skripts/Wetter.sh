echo Bearbeitung fuer $1
if [ $2x == "x" ]
then
  osascript -e 'quit app "DB Browser for SQLite"'
  if [ -e "/Volumes/User-Dokumente/WetterArchiv/$1.sqlite" ]; then rm "/Volumes/User-Dokumente/WetterArchiv/$1.sqlite"; fi;
  sqlite3 "/Volumes/User-Dokumente/WetterArchiv/$1.sqlite" < ~/Daten/Skripts/Wetter.sql
  java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Datei2Tabelle "-E/Volumes/User-Dokumente/WetterArchiv/$1.txt" "-S;" "-D/Volumes/User-Dokumente/WetterArchiv/$1.sqlite" -Tklima_tag -N -F -O
  sqlite3 "/Volumes/User-Dokumente/WetterArchiv/$1.sqlite" "DELETE FROM klima_tag WHERE STATIONS_ID == 'STATIONS_ID'; UPDATE klima_tag SET STATIONS_ID='$1';"
fi
if [ "$2" -eq "$2" ] 2>/dev/null
then
  sqlite3 "/Volumes/User-Dokumente/WetterArchiv/$1.sqlite" "UPDATE AuswahlJahr SET AuswahlJahr=$2;"
fi
if ! [ -d "/Volumes/User-Dokumente/WetterArchiv/$1" ]; then mkdir ""/Volumes/User-Dokumente/WetterArchiv/$1""; fi; 
echo "-" > "/Volumes/User-Dokumente/WetterArchiv/$1/$1-Januar.txt"
java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Tabelle2Datei "-A/Volumes/User-Dokumente/WetterArchiv/$1/$1-Januar.txt" "-D/Volumes/User-Dokumente/WetterArchiv/$1.sqlite" -TMonate "-WWHERE MonatName='Januar'" -H -O 
echo "-" > "/Volumes/User-Dokumente/WetterArchiv/$1/$1-Februar.txt"
java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Tabelle2Datei "-A/Volumes/User-Dokumente/WetterArchiv/$1/$1-Februar.txt" "-D/Volumes/User-Dokumente/WetterArchiv/$1.sqlite" -TMonate "-WWHERE MonatName='Februar'" -H -O 
echo "-" > "/Volumes/User-Dokumente/WetterArchiv/$1/$1-Maerz.txt"
java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Tabelle2Datei "-A/Volumes/User-Dokumente/WetterArchiv/$1/$1-Maerz.txt" "-D/Volumes/User-Dokumente/WetterArchiv/$1.sqlite" -TMonate "-WWHERE MonatName='Maerz'" -H -O 
echo "-" > "/Volumes/User-Dokumente/WetterArchiv/$1/$1-April.txt"
java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Tabelle2Datei "-A/Volumes/User-Dokumente/WetterArchiv/$1/$1-April.txt" "-D/Volumes/User-Dokumente/WetterArchiv/$1.sqlite" -TMonate "-WWHERE MonatName='April'" -H -O 
echo "-" > "/Volumes/User-Dokumente/WetterArchiv/$1/$1-Mai.txt"
java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Tabelle2Datei "-A/Volumes/User-Dokumente/WetterArchiv/$1/$1-Mai.txt" "-D/Volumes/User-Dokumente/WetterArchiv/$1.sqlite" -TMonate "-WWHERE MonatName='Mai'" -H -O 
echo "-" > "/Volumes/User-Dokumente/WetterArchiv/$1/$1-Juni.txt"
java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Tabelle2Datei "-A/Volumes/User-Dokumente/WetterArchiv/$1/$1-Juni.txt" "-D/Volumes/User-Dokumente/WetterArchiv/$1.sqlite" -TMonate "-WWHERE MonatName='Juni'" -H -O 
echo "-" > "/Volumes/User-Dokumente/WetterArchiv/$1/$1-Juli.txt"
java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Tabelle2Datei "-A/Volumes/User-Dokumente/WetterArchiv/$1/$1-Juli.txt" "-D/Volumes/User-Dokumente/WetterArchiv/$1.sqlite" -TMonate "-WWHERE MonatName='Juli'" -H -O 
echo "-" > "/Volumes/User-Dokumente/WetterArchiv/$1/$1-August.txt"
java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Tabelle2Datei "-A/Volumes/User-Dokumente/WetterArchiv/$1/$1-August.txt" "-D/Volumes/User-Dokumente/WetterArchiv/$1.sqlite" -TMonate "-WWHERE MonatName='August'" -H -O 
echo "-" > "/Volumes/User-Dokumente/WetterArchiv/$1/$1-September.txt"
java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Tabelle2Datei "-A/Volumes/User-Dokumente/WetterArchiv/$1/$1-September.txt" "-D/Volumes/User-Dokumente/WetterArchiv/$1.sqlite" -TMonate "-WWHERE MonatName='September'" -H -O 
echo "-" > "/Volumes/User-Dokumente/WetterArchiv/$1/$1-Oktober.txt"
java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Tabelle2Datei "-A/Volumes/User-Dokumente/WetterArchiv/$1/$1-Oktober.txt" "-D/Volumes/User-Dokumente/WetterArchiv/$1.sqlite" -TMonate "-WWHERE MonatName='Oktober'" -H -O 
echo "-" > "/Volumes/User-Dokumente/WetterArchiv/$1/$1-November.txt"
java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Tabelle2Datei "-A/Volumes/User-Dokumente/WetterArchiv/$1/$1-November.txt" "-D/Volumes/User-Dokumente/WetterArchiv/$1.sqlite" -TMonate "-WWHERE MonatName='November'" -H -O 
echo "-" > "/Volumes/User-Dokumente/WetterArchiv/$1/$1-Dezember.txt"
java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Tabelle2Datei "-A/Volumes/User-Dokumente/WetterArchiv/$1/$1-Dezember.txt" "-D/Volumes/User-Dokumente/WetterArchiv/$1.sqlite" -TMonate "-WWHERE MonatName='Dezember'" -H -O 
echo "-" > "/Volumes/User-Dokumente/WetterArchiv/$1/$1-Fruehjahr.txt"
java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Tabelle2Datei "-A/Volumes/User-Dokumente/WetterArchiv/$1/$1-Fruehjahr.txt" "-D/Volumes/User-Dokumente/WetterArchiv/$1.sqlite" -TJahreszeiten "-WWHERE Jahreszeit='Fruehjahr'" -H -O 
echo "-" > "/Volumes/User-Dokumente/WetterArchiv/$1/$1-Sommer.txt"
java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Tabelle2Datei "-A/Volumes/User-Dokumente/WetterArchiv/$1/$1-Sommer.txt" "-D/Volumes/User-Dokumente/WetterArchiv/$1.sqlite" -TJahreszeiten "-WWHERE Jahreszeit='Sommer'" -H -O 
echo "-" > "/Volumes/User-Dokumente/WetterArchiv/$1/$1-Herbst.txt"
java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Tabelle2Datei "-A/Volumes/User-Dokumente/WetterArchiv/$1/$1-Herbst.txt" "-D/Volumes/User-Dokumente/WetterArchiv/$1.sqlite" -TJahreszeiten "-WWHERE Jahreszeit='Herbst'" -H -O 
echo "-" > "/Volumes/User-Dokumente/WetterArchiv/$1/$1-Winter.txt"
java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Tabelle2Datei "-A/Volumes/User-Dokumente/WetterArchiv/$1/$1-Winter.txt" "-D/Volumes/User-Dokumente/WetterArchiv/$1.sqlite" -TJahreszeiten "-WWHERE Jahreszeit='Winter'" -H -O 
echo "-" > "/Volumes/User-Dokumente/WetterArchiv/$1/$1-Weihnachtsferien.txt"
java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Tabelle2Datei "-A/Volumes/User-Dokumente/WetterArchiv/$1/$1-Weihnachtsferien.txt" "-D/Volumes/User-Dokumente/WetterArchiv/$1.sqlite" -TFerien "-WWHERE Ferien='Weihnachtsferien'" -H -O 
echo "-" > "/Volumes/User-Dokumente/WetterArchiv/$1/$1-Sommerferien.txt"
java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Tabelle2Datei "-A/Volumes/User-Dokumente/WetterArchiv/$1/$1-Sommerferien.txt" "-D/Volumes/User-Dokumente/WetterArchiv/$1.sqlite" -TFerien "-WWHERE Ferien='Sommerferien'" -H -O 
echo "-" > "/Volumes/User-Dokumente/WetterArchiv/$1/$1-Allerheiligen.txt"
java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Tabelle2Datei "-A/Volumes/User-Dokumente/WetterArchiv/$1/$1-Allerheiligen.txt" "-D/Volumes/User-Dokumente/WetterArchiv/$1.sqlite" -TFerien "-WWHERE Ferien='Allerheiligen'" -H -O 
echo "-" > "/Volumes/User-Dokumente/WetterArchiv/$1/$1-Jahresueberblick.txt"
java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Tabelle2Datei "-A/Volumes/User-Dokumente/WetterArchiv/$1/$1-Jahresueberblick.txt" "-D/Volumes/User-Dokumente/WetterArchiv/$1.sqlite" -TJahresueberblick -H -O 
if [ $2x == "x" ]; then open -a "DB Browser for SQLite" "/Volumes/User-Dokumente/WetterArchiv/$1.sqlite"; fi;