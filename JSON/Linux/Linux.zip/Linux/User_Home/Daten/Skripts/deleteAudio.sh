dirname=$(dirname "$1")
filename=$(basename "$1")
basename="${filename%.*}"
extent="${filename##*.}"
output="$dirname/$basename.noAudio.$extent"
#
echo "Input : $1"
echo "Output: $output"
#
ffmpeg -loglevel panic -y -i "$1" -vcodec copy -an  "$output"
exiftool -tagsFromFile "$1" -all:all -overwrite_original_in_place "$output"