# ffmpeg -y -i "$1" -ss 00:30:00 -i "$2" -shortest "$1_mitAudio.mp4"
ffmpeg -y -i "$1" -i "$2" -shortest "$1_mitAudio.mp4"
exiftool -tagsFromFile "$1" -all:all -overwrite_original_in_place "$1_mitAudio.mp4"