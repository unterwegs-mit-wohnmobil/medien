ffmpeg -i "$1" -r 29.97 -vf "minterpolate=fps=50,setpts=N/(29.97*TB)"  "$1_Langsamer.mp4"
exiftool -tagsFromFile "$1" -all:all -overwrite_original_in_place "$1_Langsamer.mp4"