dirname=$(dirname "$1")
basename=$(basename "$1")
#
if [ ! -d "$dirname/_NegPos" ]
then
	mkdir "$dirname/_NegPos"
fi
convert "$1" -negate "$dirname/_NegPos/$basename"
