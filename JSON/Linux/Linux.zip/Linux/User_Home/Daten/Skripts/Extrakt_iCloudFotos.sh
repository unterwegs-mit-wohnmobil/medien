if [ -d /Volumes/Work/Bilder/f_FotosCloud ]
then
 	terminal-notifier -message "iCloud-Fotos werden extrahiert" -title "iCloud-Fotos"
	# copy iCloud-Fotos
	sqlite3 "/Volumes/Work/Bilder/f_FotosCloud/FotosWork.sqlite" "ATTACH DATABASE '/Volumes/Daten/Mediatheken/iCloud.photoslibrary/database/Photos.sqlite' AS Cloud; DELETE FROM ZCLOUDMASTER; INSERT INTO ZCLOUDMASTER SELECT ZCREATIONDATE, ZORIGINALFILENAME FROM Cloud.ZCLOUDMASTER; DELETE FROM ZGENERICASSET; INSERT INTO ZGENERICASSET SELECT ZDATECREATED, ZFILENAME, ZUUID FROM Cloud.ZGENERICASSET"
	exiftool -filename -basename -directory -originalfilename -rawfilename -make -model -DateTimeOriginal -T -r /Volumes/Daten/Mediatheken/iCloud.photoslibrary/originals/ >/Volumes/Work/Bilder/f_FotosCloud/Exif.txt 
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Datei2Tabelle -E/Volumes/Work/Bilder/f_FotosCloud/Exif.txt -CUTF-8 -D/Volumes/Work/Bilder/f_FotosCloud/FotosWork.sqlite -ToriginalsExif -N -F -O
	exiftool -filename -basename -directory -originalfilename -rawfilename -make -model -DateTimeOriginal -T -r /Volumes/Daten/Mediatheken/iCloud.photoslibrary/resources/renders/ >/Volumes/Work/Bilder/f_FotosCloud/Exif.txt 
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.Datei2Tabelle -E/Volumes/Work/Bilder/f_FotosCloud/Exif.txt -CUTF-8 -D/Volumes/Work/Bilder/f_FotosCloud/FotosWork.sqlite -TrendersExif -N -F -O
	sqlite3 "/Volumes/Work/Bilder/f_FotosCloud/FotosWork.sqlite" "DELETE From rendersExif WHERE Cloudname like '%.plist'; UPDATE rendersExif SET CloudNameBase = REPLACE(CloudNameBase,'_1_201_a',''); UPDATE originalsExif SET ZielVerz = (SELECT VerzOriginale FROM Parm); UPDATE rendersExif SET ZielVerz = (SELECT VerzBearbeitet FROM Parm); UPDATE originalsExif SET CloudVerz = CloudVerz || '/'; UPDATE rendersExif SET CloudVerz = CloudVerz || '/'"
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.SQLBatch -D/Volumes/Work/Bilder/f_FotosCloud/FotosWork.sqlite "-BSELECT Befehl FROM updateOriginalFileName" -A/Volumes/Work/Bilder/f_FotosCloud/setOriginalFileName.sh -O -S	
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.SQLBatch -D/Volumes/Work/Bilder/f_FotosCloud/FotosWork.sqlite "-BSELECT Befehl FROM updateRawFileName" -A/Volumes/Work/Bilder/f_FotosCloud/setRawFileName.sh -O -S	
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.SQLBatch -D/Volumes/Work/Bilder/f_FotosCloud/FotosWork.sqlite "-BSELECT Befehl FROM copyMedien" -A/Volumes/Work/Bilder/f_FotosCloud/copyMedien.sh -O -S
	chmod +x /Volumes/Work/Bilder/f_FotosCloud/*.sh
	/Volumes/Work/Bilder/f_FotosCloud/setOriginalFileName.sh
	/Volumes/Work/Bilder/f_FotosCloud/setRawFileName.sh
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.RenameMedien -V/Volumes/Daten/Mediatheken/iCloud.photoslibrary/originals/ -FW -W
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.RenameMedien -V/Volumes/Daten/Mediatheken/iCloud.photoslibrary/resources/renders/ -FW -W
	rm /Volumes/Work/Bilder/f_FotosCloud/Originale/*.*
	rm /Volumes/Work/Bilder/f_FotosCloud/bearbeitet/*.*
	/Volumes/Work/Bilder/f_FotosCloud/copyMedien.sh
	exiftool "-FileModifyDate<DateTimeOriginal" -ext JPG -ext PNG -ext GIF -ext MOV -ext MP4 -r -overwrite_original_in_place /Volumes/Work/Bilder/f_FotosCloud/
	java -cp ~/Java/Jar/jfi.jar de.nss.jfi.RenameMedien -V/Volumes/Work/Bilder/f_FotosCloud/ -FW -R
	terminal-notifier -message "iCloud-Fotos sind extrahiert" -title "iCloud-Fotos"
else
	echo "Platte Work nicht gemountet"
fi
