dirname=$(dirname "$1")
filename=$(basename "$1")
basename="${filename%.*}"
extent="${filename##*.}"
echo $dirname
echo $filename
echo $basename
echo $extent