#!/bin/sh

sudo cp ./libQt5X11Extras.so.5 /lib/arm-linux-gnueabihf
sudo cp ./libQt5Concurrent.so.5 /lib/arm-linux-gnueabihf
sudo cp ./libQt5Xml.so.5 /lib/arm-linux-gnueabihf
